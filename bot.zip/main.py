import discord
import os

TOKEN = 'MTIxMDM1OTM3ODYxNjY1NTk3Mg.GkVENI.QRAbc_uM30z2jXy78NlBMxTQiqLZexgpDgCuXw'

# Crea gli intents
intents = discord.Intents.default()

# Crea un'istanza del client con gli intents
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f'{client.user} è connesso e operativo!')

# Esegui il bot
client.run(TOKEN)